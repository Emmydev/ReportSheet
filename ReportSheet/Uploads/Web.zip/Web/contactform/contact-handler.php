<?php
 if(isset($_POST['submit'])){
$name= $_POST['name'];
$email= $_POST['email'];
$subject= $_POST['subject'];
$message= $_POST['message'];

$to ='ponchopowerng@gmail.com';
$email_subject=  $subject;
$email_message="Name: ".$name."\n"."Email: ".$email."\n"."Wrote the Following: "."\n\n".$message;
$headers="From: ".$email;
if (mail($to, $email_subject, $email_message, $headers)) {
echo "<script>
alert('Message Sent Successfully');
window.location.href='Home.html';
</script>";
}
else{
	echo "<script>
window.location.href='Home.html';
alert('An Error Occurred');
</script>";
}
}
?>